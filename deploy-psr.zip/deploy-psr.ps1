# 
# The script will deploy a user monitoring solution
#

$scriptPath = split-path -parent $MyInvocation.MyCommand.Definition
$scriptName = $MyInvocation.MyCommand.Name

#########################################################################
################################# Monitor ###############################
#########################################################################

### Fix mouse ###
## Default
## Set-Itemproperty -path 'HKCU:\Control Panel\Cursors' -Name 'AppStarting' -value "C:\WINDOWS\cursors\aero_working.ani"

### Create Folder Structure ###
$folderMain = "C:\system.sav"
$folderMonitor = "C:\system.sav\Monitor"
if (!(Test-Path $folderMain)){
	new-item -type Directory -Force -path $folderMain -EA SilentlyContinue
	Get-Item $folderMain -Force | foreach { $_.Attributes = $_.Attributes -bor "Hidden" }
}
else {
	Get-Item $folderMain -Force | foreach { $_.Attributes = $_.Attributes -bor "Hidden" }
}

if (!(Test-Path $folderMonitor)){
	new-item -type Directory -Force -path $folderMonitor -EA SilentlyContinue
	Get-Item $folderMonitor -Force | foreach { $_.Attributes = $_.Attributes -bor "Hidden" }
}
else {
	Get-Item $folderMonitor -Force | foreach { $_.Attributes = $_.Attributes -bor "Hidden" }
}

# Generate VBS Script
$vbScript = @"
Const HKEY_CURRENT_USER = &H80000001

Dim LocalClass_StdRegProv
Set LocalClass_StdRegProv = GetObject("winmgmts:{impersonationlevel=impersonate}!\\.\root\default:StdRegProv")

Dim result, test
LocalClass_StdRegProv.GetStringValue HKEY_CURRENT_USER, "Control Panel\Cursors", "Arrow", result 
'WScript.Echo "result=" & result
'LocalClass_StdRegProv.GetStringValue HKEY_CURRENT_USER, "Control Panel\Cursors", "AppStarting", test 
'WScript.Echo "test=" & test
LocalClass_StdRegProv.SetStringValue HKEY_CURRENT_USER, "Control Panel\Cursors", "AppStarting", result

Set oShell = CreateObject("WScript.Shell")
oShell.Run "c:\windows\System32\RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters", 1, True
WScript.Sleep 250
oShell.Run "c:\windows\System32\RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters", 1, True
WScript.Sleep 250
oShell.Run "c:\windows\System32\RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters", 1, True
WScript.Sleep 250
oShell.Run "c:\windows\System32\RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters", 1, True
WScript.Sleep 250
oShell.Run "c:\windows\System32\RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters", 1, True
WScript.Sleep 250
oShell.Run "c:\windows\System32\RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters", 1, True
WScript.Sleep 250
oShell.Run "c:\windows\System32\RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters", 1, True
WScript.Sleep 250
oShell.Run "c:\windows\System32\RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters", 1, True
WScript.Sleep 250
oShell.Run "c:\windows\System32\RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters", 1, True
WScript.Sleep 250
oShell.Run "c:\windows\System32\RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters", 1, True
WScript.Sleep 250

Do While True
	Dim sFile
	Dim sDateTimeStamp
	sDateTimeStamp = cStr(Year(now())) & "_" & _
	Pad(cStr(Month(now())),2) & "_" & _
	Pad(cStr(Day(now())),2) & "_" & _
	Pad(cStr(Hour(now())),2) & "_" & _
	Pad(cStr(Minute(now())),2) & "_" & _
	Pad(cStr(Second(now())),2)
	
	sFile = "Output_" & sDateTimeStamp & ".zip"
	
	commandStart = "C:\Windows\System32\psr.exe /start /gui 0 /sc 1 /maxsc 100 /output C:\system.sav\Monitor\" & sFile & " /stopevent 1074"
	set shell = CreateObject("WScript.Shell")
	shell.Run commandStart,0

	'WScript.Sleep 300000
	WScript.Sleep 30000
	
	commandStop = "C:\Windows\System32\psr.exe /stop"
	set shell = CreateObject("WScript.Shell")
	shell.Run commandStop,0
	
	WScript.Sleep 2000
	
	commandStop = "taskkill /f /im psr.exe"
	set shell = CreateObject("WScript.Shell")
	shell.Run commandStop,0
	
	WScript.Sleep 1000
Loop

Function Pad(CStr2Pad, ReqStrLen)
    Dim Num2Pad
 
    Pad = CStr2Pad
    If len(CStr2Pad) < ReqStrLen Then
		Num2Pad = String((ReqStrlen - Len(CStr2Pad)), "0")
		Pad = Num2Pad & CStr2Pad
    End If
End Function
"@
$vbScript | Out-File -Force "$folderMain\Monitor.vbs"

$taskName = "Win10Monitor"
$taskExists = Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskName -like $taskName }
$taskUser = (Get-WmiObject -Class win32_process | Where-Object name -Match explorer).getowner().user

if ($taskExists) {
	#Write-Host "Task $taskName Already Exists, starting it."
}
else {
    $triggers = @($(New-ScheduledTaskTrigger -AtLogon))
    Register-ScheduledTask -TaskName "$taskName" -Principal (New-ScheduledTaskPrincipal -UserId "REHMANN\$taskUser" -RunLevel Highest) -Trigger $triggers -Action (New-ScheduledTaskAction -Execute "C:\Windows\System32\wscript.exe" -Argument "//nologo $folderMain\Monitor.vbs") -Settings (New-ScheduledTaskSettingsSet -StartWhenAvailable -ExecutionTimeLimit 0 -Compatibility Win8 -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -Hidden) -Force
}

Start-ScheduledTask -TaskName $taskName